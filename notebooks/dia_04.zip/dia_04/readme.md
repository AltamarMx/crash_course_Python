#  Día 04: Manejo y vis de datos con pandas P1

1. Intro a pandas
1. Carga datos de csv y hojas de c'alculo
1. Operaciones y visualizacion de datos tipo x,y
1. Operaciones y visualizacion de datos categ'oricos
